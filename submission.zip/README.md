# Assignment 1: Multi-Layer Perceptron for Image Classification

## Results and report
- **Repository link**: https://github.com/aadarshram/da6401_assignment_1 
- **W&B Report**: https://wandb.ai/ramachandranaadarsh-indian-institute-of-technology-madras/da6401_assignment_1/reports/DA6401-Assignment-1-Report--VmlldzoxNjEyMTg1Ng?accessToken=v7zjwto3ql0mj9famz978npvm7xhqtybcaks74kyetpww038sgm3e6wvx2ugoaux 

## Instructions

## Overview

This assignment requires you to implement a neural network from scratch using only NumPy. You will build all components including layers, activations, optimizers, and loss functions, then train your network on MNIST or Fashion-MNIST datasets.

## Learning Objectives

- Understand forward and backward propagation
- Implement gradient computation manually
- Implement various optimizers (SGD, Momentum, Adam, Nadam)
- Work with activation functions and their derivatives
- Train and evaluate neural networks
- Log experiments using Weights & Biases

## Contact

For questions or issues, please contact the teaching staff or post on the course forum.

---

Good luck with your implementation!
